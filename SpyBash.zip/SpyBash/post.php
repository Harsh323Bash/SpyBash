<?php
$data = file_get_contents("php://input");
$filename = "cam" . date("dMYHis") . ".png";
file_put_contents($filename, $data);
?>